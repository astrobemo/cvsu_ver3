'<?php echo link_tag('assets/global/plugins/jqvmap/jqvmap/jqvmap.css'); ?>
<?php echo link_tag('assets/global/plugins/morris/morris.css'); ?>

		<div class="modal fade bs-modal-lg" id="portlet-remove-note-order" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('admin/note_order_remove')?>" class="form-horizontal" id="form_remove_note_order" method="post">
							
			                <div class="form-group">
			                    <label class="control-label col-md-3">Alasan Batal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
									<input name="alasan_batal" class="form-control">
			                    </div>				                    
			                </div>

			               
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn blue btn-remove-nota-order">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="page-content">
			<div class='container'>
				<div class="row margin-top-10">
					<div class="col-md-12">
						<div class="portlet light ">
							<div class="portlet-title">
								<div class="caption caption-md">
									<i class="icon-bar-chart theme-font hide"></i>
									<span class="caption-subject theme-font bold uppercase">Dashboard</span>
									<!-- <span class="caption-helper hide">weekly stats...</span> -->
								</div>
								<div class="actions">
									<!-- <div class="btn-group btn-group-devided" data-toggle="buttons">
										<label class="btn btn-transparent grey-salsa btn-circle btn-sm active">
										<input type="radio" name="options" class="toggle" id="option1">Today</label>
										<label class="btn btn-transparent grey-salsa btn-circle btn-sm">
										<input type="radio" name="options" class="toggle" id="option2">Week</label>
										<label class="btn btn-transparent grey-salsa btn-circle btn-sm">
										<input type="radio" name="options" class="toggle" id="option2">Month</label>
									</div> -->
								</div>
							</div>
							<div class="portlet-body">

								<?if (is_posisi_id() < 3) { ?>
									<div class='note note-info'>
										<b>INFO : </b> <br/>
										1. Halaman dashboard telah dipindahkan ke Halaman
										<a href="<?=base_url().is_setting_link('report/penjualan_general_report');?>">Laporan -> Laporan Umum <i class='fa fa-link'></i></a> <br>
										2. Menu <b><i class='fa fa-shopping-cart'></i>Transaksi<i class='fa fa-arrow-right'></i>Laporan Penerimaan</b> kini berada di Menu <b> <i class='icon-graph'></i>Laporan<i class='fa fa-arrow-right'></i>Laporan Penerimaan</b>
									</div>

								<?}?>

								<hr/>
								<h4>Catatan Pesanan</h4>
								<table class='table' id='note_order_table'>
									<thead>
										<tr>
											<th>No</th>
											<th>Tanggal Input</th>
											<th>Tanggal Target</th>
											<th>Customer</th>
											<th>Tipe Barang</th>
											<th>Barang</th>
											<th>Warna</th>
											<th>Qty</th>
											<th>Harga</th>
											<!-- <th>Status</th> -->
											<?//if (is_posisi_id() < 4) { ?>
												<th>Action</th>
											<?//}?>
										</tr>
									</thead>
									<tbody>
										<?
										$idx = 1;
										foreach (get_note_order() as $row) {?>
											<tr <?/*style="<?=($row->matched == 1 ? 'border:2px solid red' : '');?>" */?>>
												<td>
													<?=$idx;?>
													<?if ($row->matched == 1) { ?>
														<span style='color:red'><i class='fa fa-flag'></i></span>
													<?}?>
												</td>
												<td><span class='tanggal_note_order'><?=is_reverse_datetime2($row->tanggal_note_order);?></span> </td>
												<td><span class='tanggal_target'><?=is_reverse_date($row->tanggal_target);?></span></td>
												<td>
													<span class='tipe_customer' hidden><?=$row->tipe_customer?></span>
													<span class='customer_id' hidden><?=$row->customer_id;?></span>
													<span class='nama_customer'><?=$row->nama_customer;?></span> - 
													<span class='contact_info'><?=$row->contact_info;?></span>
												</td>
												<td>
													<span class='tipe_barang' hidden><?=$row->tipe_barang;?></span>
													<span class='barang_id' hidden><?=$row->barang_id;?></span>
													<?=($row->tipe_barang==1 ? 'terdaftar' : 'tidak terdaftar');?></td>
												<td><span class='nama_barang'><?=$row->nama_barang;?></span></td>
												<td><span class='warna_id' hidden><?=$row->warna_id;?></span><?=$row->nama_warna;?></td>
												<td><span class='qty'><?=is_qty_general($row->qty);?></span></td>
												<td>
													<span class='harga'><?=number_format($row->harga,'0',',','.');?></span>
													
													<span class='id' hidden><?=$row->id;?></span>
												</td>
												<?//if (is_posisi_id() < 4) { ?>
													<td>
														<span class='status' hidden><?=$row->status;?></span>
														<form action="<?=base_url('admin/set_reminder');?>" hidden class='form-reminder'>
															<input name='note_order_id' value="<?=$row->id;?>" hidden>
															<input name='reminder' class='form_datetime'> <button><i class='fa fa-check'></i></button>
														</form>
														<?if ($row->status == 1) { ?>
															<button class='btn btn-xs blue check_note_order'><i class='fa fa-check'></i> completed by <?=is_get_username($row->done_by);?> <?=is_reverse_datetime($row->done_time);?></button>
														<?}elseif($row->status == -1){?>
															<button class='btn btn-xs red check_note_order'><i class='fa fa-times'></i> cancel by <?=is_get_username($row->done_by);?> <?=is_reverse_datetime($row->done_time);?></button>
														<?}else{?>
															<button class='btn btn-xs default btn-reminder'> <i class='fa fa-plus'></i> <i class='fa fa-clock-o'></i></button>
															<button class='btn btn-xs green btn-edit'> <i class='fa fa-edit'></i></button>
															<button class='btn btn-xs red btn-remove'> <i class='fa fa-times'></i></button>
															<button class='btn btn-xs default check_note_order'> completed</button>
															
															<!-- <input type='checkbox' class='check_note_order' <?=($row->done_by != '' ? 'checked' : '');?> > -->
														<?}?>
													</td>
												<?//}?>
											</tr>
										<?$idx++;}?>
									</tbody>
								</table>


							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>

		<script src="<?php echo base_url('assets/global/plugins/bootbox/bootbox.min.js'); ?>" type="text/javascript"></script>

		<script>
		jQuery(document).ready(function() {
			
			<?if (is_posisi_id() < 4) { ?>
				$('#note_order_table').on('dblclick','.check_note_order', function(){
					var id = $(this).closest('tr').find('.id').html();
					var status = 1;
					var done_by = $(this).closest('tr').find('.status').html();
					if (done_by == '1' || done_by == '-1') {
						status = 0;
					};
					// alert(status);
					window.location.replace(baseurl+"admin/note_order_status_update?id="+id+"&status="+status);
				});

				$('#note_order_table').on('dblclick','.btn-remove', function(){
					var id = $(this).closest('tr').find('.id').html();
					var status = -1;
					// alert(status);
					window.location.replace(baseurl+"admin/note_order_status_update?id="+id+"&status="+status);
				});

				// $('.btn-remove-nota-order').click( function(){
				// 	var id = $(this).closest('tr').find('.id').html();
				// 	var status = -1;
				// 	// alert(status);
				// 	window.location.replace(baseurl+"admin/note_order_status_update?id="+id+"&status="+status);
				// });

				// btn-remove-nota-order

				$("#note_order_table").on('click','.btn-edit', function(){
					var form = '#form_add_note_order';
					var ini = $(this).closest('tr');
					$(form+" [name=id]").val(ini.find('.id').html());
					$(form+" [name=tanggal_note_order]").val(ini.find('.tanggal_note_order').html());
					$(form+" [name=tanggal_target]").val(ini.find('.tanggal_target').html());
					
					var tipe_customer = ini.find('.tipe_customer').html();
					$(form+" [name=tipe_customer][value="+tipe_customer+"]").prop("checked", true);
					$.uniform.update($(form+" [name=tipe_customer]"));
					if (tipe_customer == 1) {
			    		$('.note-customer').show();
			    		$('.note-non-customer').hide();
			    	}else{
			    		$('.note-customer').hide();
			    		$('.note-non-customer').show();
			    	};

					$(form+" [name=customer_id]").val(ini.find('.customer_id').html());
					$(form+" [name=nama_customer]").val(ini.find('.nama_customer').html());
					$(form+" [name=contact_info]").val(ini.find('.contact_info').html());
					
					var tipe_barang = ini.find('.tipe_barang').html();
					$(form+" [name=tipe_barang][value="+tipe_barang+"]").prop("checked", true);
					$.uniform.update($(form+" [name=tipe_barang]"));
					if (tipe_barang == 1) {
			    		$('#barang_terdaftar').show();
			    		$('#barang_tidak_terdaftar').hide();
			    	}else if (tipe_barang == 2) {
			    		$('#barang_terdaftar').hide();
			    		$('#barang_tidak_terdaftar').show();
			    	};


					$(form+" [name=barang_id]").val(ini.find('.barang_id').html());
					$(form+" [name=warna_id]").val(ini.find('.warna_id').html()).trigger('change.select2');;
					$(form+" [name=nama_barang]").val(ini.find('.nama_barang').html());
					$(form+" [name=qty]").val(ini.find('.qty').html());
					$(form+" [name=harga]").val(ini.find('.harga').html());
					$("#portlet-config-note-order").modal('toggle');
				});

				$("#note_order_table").on('click', '.btn-reminder', function(){
					var ini = $(this).closest('tr');
					// $('.form-reminder').hide();
					ini.find('.form-reminder').toggle();
				});

			<?}?>
		});
		</script>

<? /*
<script src="<?=base_url('assets/global/plugins/morris/morris.min.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/morris/raphael-min.js');?>" type="text/javascript"></script>


<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/amcharts.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/serial.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/themes/light.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/pie.js');?>" type="text/javascript"></script>

<script src="<?=base_url('assets_noondev/js/charts-amcharts.js');?>"></script>
<script src="<?=base_url('assets_noondev/js/index3.js'); ?>" type="text/javascript"></script>

<script>
$(document).ready(function() {   
	//$("#sidebar").load("sidebar.html"); 
   	Metronic.init(); // init metronic core componets
   	Layout.init(); // init layout
   	Index.init(); // init index page
   	ChartsAmcharts.init(); 

    
});
</script>
<!-- END JAVASCRIPTS -->
*/?>