'<?php echo link_tag('assets/global/plugins/jqvmap/jqvmap/jqvmap.css'); ?>
<?php echo link_tag('assets/global/plugins/morris/morris.css'); ?>

		<div class="page-content">
			<div class='container'>
				<div class="row margin-top-10">
					<div class="col-md-12">
						<div class="portlet light ">
							<div class="portlet-title">
								<div class="caption caption-md">
									<i class="icon-bar-chart theme-font hide"></i>
									<span class="caption-subject theme-font bold uppercase">Dashboard</span>
									<!-- <span class="caption-helper hide">weekly stats...</span> -->
								</div>
								<div class="actions">
									<!-- <div class="btn-group btn-group-devided" data-toggle="buttons">
										<label class="btn btn-transparent grey-salsa btn-circle btn-sm active">
										<input type="radio" name="options" class="toggle" id="option1">Today</label>
										<label class="btn btn-transparent grey-salsa btn-circle btn-sm">
										<input type="radio" name="options" class="toggle" id="option2">Week</label>
										<label class="btn btn-transparent grey-salsa btn-circle btn-sm">
										<input type="radio" name="options" class="toggle" id="option2">Month</label>
									</div> -->
								</div>
							</div>
							<div class="portlet-body">

								<div class='note note-info'>
									<b>INFO : </b> <br/>
									1. Menu <b><i class='fa fa-shopping-cart'></i>Transaksi<i class='fa fa-arrow-right'></i>Laporan Penerimaan</b> kini berada di Menu <b> <i class='icon-graph'></i>Laporan<i class='fa fa-arrow-right'></i>Laporan Penerimaan</b>
								</div>


							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>



<script>
$(document).ready(function() {   
	//$("#sidebar").load("sidebar.html"); 
   	Metronic.init(); // init metronic core componets
   	Layout.init(); // init layout
   	// Index.init(); // init index page
   	// ChartsAmcharts.init(); 

    
});
</script>
<!-- END JAVASCRIPTS -->
