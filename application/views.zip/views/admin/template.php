<?=$this->load->view('admin/includes/header')?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <?=$this->load->view($content)?>
        </div>

        <!-- /#page-wrapper -->
<?=$this->load->view('admin/includes/footer')?>