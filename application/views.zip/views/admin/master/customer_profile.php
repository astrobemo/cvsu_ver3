<?php echo link_tag('assets/global/plugins/jqvmap/jqvmap/jqvmap.css'); ?>
<?php echo link_tag('assets/global/plugins/morris/morris.css'); ?>

<style type="text/css">
#tbl-data input[type="text"], #tbl-data select{
	height: 25px;
	width: 50%;
	padding: 0 5px;
}

#qty-table input{
	width: 80px;
	padding: 5px;
}

#stok-info{
	font-size: 1.5em;
	position: absolute;
	right: 50px;
	top: 30px;
}

.yard-info{
	font-size: 1.5em;
}

.no-faktur-lengkap{
	font-size: 2.5em;
	font-weight: bold;
}

.input-no-border{
	border: none;
}

.subtotal-data{
	font-size: 1.2em;
}

#bayar-data tr td{
	font-size: 1.5em;
	font-weight: bold;
	padding: 0 10px 0 10px;
}

#bayar-data tr td input{
	padding: 0 5px 0 5px;
	border: 1px solid #ddd;
}

</style>

<div class="page-content">
	<div class='container'>


		<div class="row margin-top-10">
			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase">Data Customer</span>
						</div>
					</div>
					<div class="portlet-body">
						<table style='width:100%'>
							<?foreach ($data_customer as $row) { ?>
								<tr>
									<td>
										<i class='fa fa-user'></i>
									</td>
									<td>
										:
									</td>
									<td>
										<?=$row->nama;?>
									</td>
								</tr>
								<tr>
									<td>
										<i class='fa fa-home'></i> 
									</td>
									<td>
										:
									</td>
									<td>
										<?=$row->alamat;?>
									</td>
								</tr>
								<tr>
									<td>
										<i class='fa fa-phone'></i> 
									</td>
									<td>
										:
									</td>
									<td>
										<?=$row->telepon1;?>/<?=$row->telepon2;?>
									</td>
								</tr>
								<tr>
									<td>
										<i class='fa fa-credit-card'></i>
									</td>
									<td>
										:
									</td>
									<td>
										<?=$row->npwp;?>
									</td>
								</tr>
								<tr>
									<td>
										<i class='fa fa-globe'></i>
									</td>
									<td>
										:
									</td>
									<td>
										<?=$row->kota;?>
									</td>
								</tr>
								<tr>
									<td>
										<i class='icon-envelope-letter'></i> 
									</td>
									<td>
										:
									</td>
									<td>
										<?=$row->email;?>
									</td>
								</tr>
							<?}?>
						</table>
					</div>
					
				</div>
			</div>

			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase">History</span>
						</div>
					</div>
					<div class="portlet-body">
						<h4><b>30 Transaksi Terakhir <?=date('Y');?></b> </h4>
						<table class="table table-hover table-bordered" id="general_table">
							<thead>
								<tr>
									<th scope="col">
										No Faktur
									</th>
									<th scope="col">
										Tanggal
									</th>
									<th scope="col">
										Tipe
									</th>
									<th scope="col">
										Total
									</th>
									<th scope="col" class='text-center'>
										Keterangan
									</th>
									<th scope="col">
										Status 
									</th>
								</tr>
							</thead>
							<tbody>
								<?foreach ($data_penjualan as $row) { ?>
									<tr>
										<td>
											<a href="<?=base_url().is_setting_link('transaction/penjualan_list_detail')?>?id=<?=$row->penjualan_id;?>" target='_blank'><?=$row->no_faktur;?></a> 
										</td>
										<td>
											<?=is_reverse_date($row->tanggal);?>
										</td>
										<td>
											<?=$row->tipe_penjualan;?>
										</td>
										<td>
											<?=number_format($row->g_total,'2',',','.');?>
										</td>
										<td class='text-center'>
											<?if ($row->keterangan < 0) { ?>
												<span style='color:red'>belum lunas</span>
											<?}else { ?>
												<span style='color:green'>lunas</span>
											<?}?>
										</td>
										<td>
											
										</td>
									</tr>
								<?}?>
							</tbody>
						</table>
						<div class="row list-separated">
							<hr/>
							<div class="col-md-4 col-sm-6 col-xs-6">
								<div class="font-grey-mint font-sm">
									Total Piutang
								</div>
								<div class="uppercase font-hg font-purple">
									<?foreach ($customer_profile_hutang as $row) { ?>
										Rp <?=number_format($row->sisa_piutang,'0',',','.')?> <span class="font-lg font-grey-mint"></span>
									<?}?>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 col-xs-6">
								<div class="font-grey-mint font-sm">
									Saldo DP
								</div>
								<div class="uppercase font-hg font-blue">
									<?foreach ($customer_dp as $row) { ?>
										Rp <?=number_format($row->saldo,'0',',','.')?> <span class="font-lg font-grey-mint"></span>
									<?}?>
								</div>
							</div>
							<hr/>
						</div>

						<div class="row list-separated">
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<h4><b>Chart Rekap Transaksi Per Bulan Tahun <?=date('Y');?></b> </h4>
								<div id="chart_1" class="chart" style="height: 300px;">
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<h4><b>10 Penjualan Barang Terbanyak <?=date('Y');?></b> </h4>

								<div id="chart_2" class="chart" style="height: 300px;">
								</div>
								
							</div>

						</div>
						<div class="row list-separated">
						
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<h4><b>10 Penjualan Barang Terbanyak <?=date('Y');?></b> </h4>

								<div id="chart_3" class="chart" style="height: 400px;">
								</div>
								
							</div>

						</div>
					</div>

					<span id='customer_id_data' hidden='hidden'><?=$customer_id;?></span>
					
				</div>
			</div>
		</div>
	</div>			
</div>

<script src="<?=base_url('assets/global/plugins/morris/morris.min.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/morris/raphael-min.js');?>" type="text/javascript"></script>


<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/amcharts.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/serial.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/themes/light.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/global/plugins/amcharts/amcharts/pie.js');?>" type="text/javascript"></script>

<script src="<?=base_url('assets_noondev/js/charts-amcharts-cust.js');?>"></script>


<script>
jQuery(document).ready(function() {

   	ChartsAmcharts.init(); 

	
});

</script>
