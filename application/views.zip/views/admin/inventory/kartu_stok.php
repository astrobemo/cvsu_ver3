<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css'); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/extensions/ColReorder/css/dataTables.colReorder.min.css'); ?>"/>
<?=link_tag('assets/global/plugins/bootstrap-datepicker/css/datepicker3.css'); ?>

<style type="text/css">
#general_table tr td, #general_table tr th {
	text-align: center;
	vertical-align: middle;
}
</style>

<div class="page-content">
	<div class='container'>

		<div class="modal fade" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('inventory/penyesuaian_stok_insert')?>" class="form-horizontal" id="form_add_data" method="post">
							<h3 class='block'> Penyesuaian Barang</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-4">Tipe<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
					                <div class='radio-list'>
					                	<label class="radio-inline">
					                		<input type='radio' class='form-control' checked name='tipe_transaksi' value='1'> Barang Masuk
					                	</label>
					                	<label class="radio-inline">
					                		<input type='radio' class='form-control' name='tipe_transaksi' value='2'> Barang Keluar
					                	</label>
					                </div>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-4">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<input name='barang_id' value='<?=$barang_id?>' hidden='hidden'>
			                    	<input name='warna_id' value='<?=$warna_id?>' hidden='hidden'>
			                    	<input name='gudang_id' value='<?=$gudang_id;?>' hidden='hidden'>
					                <input name="tanggal" type="text" readonly class="form-control date-picker" value="<?=date('d/m/Y');?>" />
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-4">Qty
			                    </label>
			                    <div class="col-md-6">
									<input type="text" class='form-control' name="qty"/>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-4">Jumlah Roll
			                    </label>
			                    <div class="col-md-6">
									<input type="text" class='form-control' name="jumlah_roll"/>
			                    </div>
			                </div> 

						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-save">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="modal fade" id="portlet-config-edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('inventory/penyesuaian_stok_update')?>" class="form-horizontal" id="form_edit_data" method="post">
							<h3 class='block'> Penyesuaian Barang</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-4">Tipe<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
					                <div class='radio-list'>
					                	<label class="radio-inline">
					                		<input type='radio' class='form-control' name='tipe_transaksi' value='1'> Barang Masuk
					                	</label>
					                	<label class="radio-inline">
					                		<input type='radio' class='form-control' name='tipe_transaksi' value='2'> Barang Keluar
					                	</label>
					                </div>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-4">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<input name='barang_id' value='<?=$barang_id?>' hidden='hidden'>
			                    	<input name='warna_id' value='<?=$warna_id?>' hidden='hidden'>
			                    	<input name='gudang_id' value='<?=$gudang_id;?>' hidden='hidden'>
			                    	<input name='penyesuaian_stok_id' hidden='hidden'>
				                	<input name="tanggal" type="text" readonly class="form-control date-picker" />
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-4">Qty
			                    </label>
			                    <div class="col-md-6">
									<input type="text" class='form-control' name="qty"/>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-4">Jumlah Roll
			                    </label>
			                    <div class="col-md-6">
									<input type="text" class='form-control' name="jumlah_roll"/>
			                    </div>
			                </div> 

						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-edit-save">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<form id="form_remove_data" action="<?=base_url('inventory/penyesuaian_stok_remove')?>" method='post'>
			<input name='barang_id' value='<?=$barang_id?>' hidden='hidden'>
        	<input name='warna_id' value='<?=$warna_id?>' hidden='hidden'>
        	<input name='gudang_id' value='<?=$gudang_id;?>' hidden='hidden'>
        	<input name='penyesuaian_stok_id' hidden='hidden'>
		</form>

		<div class="row margin-top-10">
			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase"><?=$breadcrumb_small;?></span>
						</div>
						<?if (is_posisi_id() < 3) { ?>
							<div class="actions">
								<a href="#portlet-config" data-toggle='modal' class="btn btn-default btn-sm btn-form-add hidden-print">
								<i class="fa fa-plus"></i> Tambah </a>
							</div>
						<?}?>
					</div>
					<div class="portlet-body">
						<form action='' method='get'>
							<table>
								<tr>
									<td>Lokasi</td>
									<td class='padding-rl-5'> : </td>
									<td><b><?=$nama_gudang;?></b></td>
								</tr>
								<tr>
									<td>Nama/Warna</td>
									<td class='padding-rl-5'> : </td>
									<td><b><?=$nama_beli.' '.$warna_beli.' || '.$nama_jual.' '.$warna_jual;?></b></td>
								</tr>
								<tr>
									<td>Tanggal Stok</td>
									<td class='padding-rl-5'> : </td>
									<td>
										<b>
											<input name='tanggal_start' readonly class='date-picker' style='border:none; border-bottom:1px solid #ddd; width:100px;' value='<?=$tanggal_start;?>'>
											s/d
											<input name='tanggal_end' readonly class='date-picker2 ' style='border:none; border-bottom:1px solid #ddd; width:100px;' value='<?=$tanggal_end;?>'> 
											<button class='btn btn-xs default'><i class='fa fa-search'></i></button>
										</b>
									</td>
								</tr>
							</table>
							
							
						</form>
						<hr/>
						<?
							$qty = 0;
							$roll = 0;
							?>
						<table class="table table-striped table-bordered table-hover" id="general_table">
							<thead>
								<tr>
									<th scope="col" rowspan='2'>
										Tanggal
									</th>
									<th scope="col" rowspan='2'>
										Keterangan
									</th>
									<th scope="col" colspan='2'>
										Masuk
									</th>
									<th scope="col" colspan='2'>
										Keluar
									</th>
									<th colspan='2'>
										Saldo
									</th>
								</tr>
								<tr>
									<th scope="col">
										Qty
									</th>
									<th scope="col">
										Jumlah Roll
									</th>
									<th scope="col">
										Qty
									</th>
									<th scope="col">
										Jumlah Roll
									</th>
									<th scope="col">
										Qty
									</th>
									<th scope="col">
										Jumlah Roll
									</th>

								</tr>
							</thead>
							<tbody>
								<?
								// print_r($stok_awal);
								foreach ($stok_awal as $row) { ?>
									<tr>
										<td>
											<b>Stok Awal</b>
										</td>
										<td></td>
										<td>
											<?=($row->qty_masuk == 0 ?  '-' :  $row->qty_masuk );?>
											<?$qty += $row->qty_masuk;?>
										</td>
										<td>
											<?=($row->jumlah_roll_masuk == 0 ? '-' : $row->jumlah_roll_masuk ) ;?>
											<?$roll += $row->jumlah_roll_masuk;?>

										</td>

										<td>
											<?=($row->qty_keluar == 0 ? '-' : $row->qty_keluar );?>
											<?$qty -= $row->qty_keluar;?>

										</td>
										<td>
											<?=($row->jumlah_roll_keluar == 0 ? '-' : $row->jumlah_roll_keluar ) ;?>
											<?$roll-= $row->jumlah_roll_keluar;?>

										</td>
										<td <? if ($qty < 0): echo "style='color:red'"; endif ?>>
											<b><?=number_format($qty,'2',',','.');?></b> 
										</td>
										<td <? if ($roll < 0): echo "style='color:red'"; endif ?>>
											<b><?=number_format($roll,'0',',','.');?></b> 
										</td>
									</tr>
								<?}?>
								<?foreach ($stok_barang as $row) { ?>
									<tr>
										<td>
											<?=date('d F Y', strtotime($row->tanggal));?>
											<span class='tanggal' hidden='hidden'><?=$row->tanggal?></span>
										</td>
										<td>
											<?if ($row->tipe == 'a1' || $row->tipe == 'a2' || $row->tipe == 'a3') {
												if (is_posisi_id() < 3) {
													if ($row->tipe == 'a1') { ?>
														<a terget='_blank' href="<?=base_url().is_setting_link('transaction/pembelian_list_detail').'/'.$row->trx_id;?>"><?=$row->no_faktur;?></a>
													<?}elseif ($row->tipe == 'a2') { ?>
														<a terget='_blank' href="<?=base_url().is_setting_link('transaction/penjualan_list_detail').'?id='.$row->trx_id;?>"><?=$row->no_faktur;?></a>
													<?}elseif ($row->tipe == 'a3') { ?>
														<a terget='_blank' href="<?=base_url().is_setting_link('transaction/retur_jual_detail').'?id='.$row->trx_id;?>"><?=$row->no_faktur;?></a>
													<?}
												}else{
													echo $row->no_faktur;
												}
											}else if ($row->tipe == '1' || $row->tipe == '2' ) {
												$user = explode('??', $row->no_faktur);
												?>
												<!-- <?=$row->no_faktur;?> -->
												Pemutihan oleh: <b><?=$user[0];?></b>  
												<span class='user_id' hidden='hidden'><?=$user[1];?></span>
												<span class='penyesuaian_stok_id' hidden='hidden'><?=$user[2];?></span>
												<span class='tipe' hidden='hidden'><?=$row->tipe;?></span>
												<?
													if (is_posisi_id() < 2) { ?>
														<a href="#portlet-config-edit" data-toggle='modal' class='btn btn-xs blue btn-edit'><i class='fa fa-edit'></i></a>
														<a class='btn btn-xs red btn-remove'><i class='fa fa-times'></i></a>
													<? }
												
											}elseif ($row->tipe == 'b1') {
												echo "mutasi barang dari ".$row->no_faktur." ke ".$nama_gudang;
											}elseif ($row->tipe == 'b2') {
												echo "mutasi barang dari ".$nama_gudang." ke ".$row->no_faktur."";
											}else if($row->tipe == 0 && $row->tipe != 'b1' && $row->tipe != 'b2'){
												echo "<b>Mutasi Stok Awal</b>";
											}?>
										</td>
										<td>
											<?=($row->qty_masuk == 0 ?  '-' : "<span class='qty'>".$row->qty_masuk."</span>" );?>
											<?$qty += $row->qty_masuk;?>
										</td>
										<td>
											<?=($row->jumlah_roll_masuk == 0 ? '-' : "<span class='jumlah_roll'>".$row->jumlah_roll_masuk."</span>" ) ;?>
											<?$roll += $row->jumlah_roll_masuk;?>
										</td>

										<td>
											<?=($row->qty_keluar == 0 ? '-' : "<span class='qty'>".$row->qty_keluar."</span>" );?>
											<?$qty -= $row->qty_keluar;?>

										</td>
										<td>
											<?=($row->jumlah_roll_keluar == 0 && $row->qty_keluar == 0 ? '-' : "<span class='jumlah_roll'>".$row->jumlah_roll_keluar."</span>" ) ;?>
											<?$roll-= $row->jumlah_roll_keluar;?>

										</td>
										<td <? if ($qty < 0): echo "style='color:red'"; endif ?>>
											<b><?=number_format($qty,'2',',','.');?></b> 
										</td>
										<td <? if ($roll < 0): echo "style='color:red'"; endif ?>>
											<b><?=number_format($roll,'0',',','.');?></b> 
										</td>
									</tr>
								<? } ?>

							</tbody>
						</table>
						<div>
		                	<a href="javascript:window.open('','_self').close();" class="btn default button-previous hidden-print">Close</a>
		                	<button onclick='window.print()' class="btn blue hidden-print"><i class='fa fa-print'></i> Print</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>			
</div>

<script src="<?php echo base_url('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<script src="<?php echo base_url('assets/global/plugins/datatables/media/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets_noondev/js/table-advanced.js'); ?>"></script>
<script src="<?php echo base_url('assets/global/plugins/bootbox/bootbox.min.js'); ?>" type="text/javascript"></script>

<script>
jQuery(document).ready(function() {
	Metronic.init(); // init metronic core components
	Layout.init(); // init current layout
	
	
	
   	$('#general_table').on('click', '.btn-edit', function(){
   		$('#form_edit_data [name=penyesuaian_stok_id]').val($(this).closest('tr').find('.penyesuaian_stok_id').html());
   		$('#form_edit_data [name=tanggal]').val(date_formatter($(this).closest('tr').find('.tanggal').html()));
   		$('#form_edit_data [name=qty]').val($(this).closest('tr').find('.qty').html());
   		$('#form_edit_data [name=jumlah_roll]').val($(this).closest('tr').find('.jumlah_roll').html());
   		var tipe = $(this).closest('tr').find('.tipe').html();
   		$('#form_edit_data [name=tipe_transaksi][value='+tipe+']').prop('checked','checked');
   		$.uniform.update($('#form_edit_data [name=tipe_transaksi]'));

   	});


   	$('.btn-save').click(function(){
   		if( $('#form_add_data [name=tanggal]').val() != '' ){
   			$('#form_add_data').submit();
   		}
   	});

   	$('.btn-edit-save').click(function(){
   		if( $('#form_edit_data [name=tanggal]').val() != ''){
   			$('#form_edit_data').submit();
   		}
   	});

   	$('#general_table').on('click','.btn-remove', function(){
   		$('#form_remove_data [name=penyesuaian_stok_id]').val($(this).closest('tr').find('.penyesuaian_stok_id').html());
   		bootbox.confirm("Hapus penyesuaian stok ini ? ", function(respond){
   			if (respond) {
   				$('#form_remove_data').submit();
   			};
   		});

   	});
});
</script>
