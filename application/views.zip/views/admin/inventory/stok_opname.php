<style type="text/css">
	#general_table{
		width: 100%;
		border-collapse: collapse
	}

	#general_table tr td,#general_table tr th{
		border: 1px solid black;
		padding: 5px ;
	}
</style>
<button class='hidden-print' onclick='window.print()'>PRINT</button>
<table id="general_table">
<thead>
	<tr>
		<th scope="col" rowspan='2'>
			ID
		</th>
		<th scope="col" rowspan='2'>
			Nama Beli
		</th>
		<th scope="col" rowspan='2'>
			Nama Jual
		</th>
		<?foreach ($this->gudang_list_aktif as $row) { ?>
			<?if ($row->id == 1) {?>
				<th colspan='2' style='text-align:left'><?//=$row->nama;?>LOKASI : </th>
			<?}?>
		<?}?>
	</tr>
	<tr>
		<?foreach ($this->gudang_list_aktif as $row) { ?>
			<?if ($row->id == 1) {?>
				<th>Yard/Kg</th>
				<th>Jumlah Roll</th>
			<?}?>

		<?}?>
	</tr>
</thead>
<tbody>
	<?
	$i = 1;
	foreach ($stok_barang as $row) { ?>
		<tr>
			<td><?=$row->barang_id.'.'.$row->warna_id;?></td>
			<td>
				<span class='barang_id' hidden="hidden"><?=$row->barang_id;?></span>
				<?=$row->nama_barang;?> <?=$row->nama_warna;?>
				<?//=$row->barang_id;?><?//=$row->warna_id;?>
			</td>
			<td>
				<?=$row->nama_barang_jual;?> <?=$row->nama_warna_jual;?>
			</td>
			
			<?foreach ($this->gudang_list_aktif as $isi) { ?>
				<?if ($isi->id == 1) { ?>
					<?
					$qty = $isi->nama.'_qty';
					$roll = $isi->nama.'_roll'
					?>
					<td><?//=$row->$qty;?> <?//=$row->nama_satuan;?></td>
					<td><?//=$row->$roll;?></td>
				<?}?>
			<?}?>
		</tr>
	<? $i++; } ?>

</tbody>
</table>