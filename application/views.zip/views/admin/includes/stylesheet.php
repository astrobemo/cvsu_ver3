<!-- BEGIN GLOBAL MANDATORY STYLES -->
<?php echo link_tag('assets_noondev/css/google-font-open-sans-400-300-600-700.css'); ?>
<?php echo link_tag('assets/global/plugins/font-awesome/css/font-awesome.min.css'); ?>
<?php echo link_tag('assets/global/plugins/simple-line-icons/simple-line-icons.min.css'); ?>
<?php echo link_tag('assets/global/plugins/bootstrap/css/bootstrap.min.css'); ?>
<?php echo link_tag('assets/global/plugins/uniform/css/uniform.default.css'); ?>
<?php echo link_tag('assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css'); ?>
<!-- END GLOBAL MANDATORY STYLES -->

<?php echo link_tag('assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css'); ?>

<!-- BEGIN PAGE LEVEL PLUGIN STYLES -->

<?php echo link_tag('assets/global/plugins/jqvmap/jqvmap/jqvmap.css'); ?>
<?php echo link_tag('assets/global/plugins/morris/morris.css'); ?>
<!-- END PAGE LEVEL PLUGIN STYLES -->


<!-- END PAGE STYLES -->

<!--?php echo link_tag('assets/global/plugins/dropzone/css/dropzone.css'); ?-->
<!--?php echo link_tag('assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css'); ?-->
<?php echo link_tag('assets/global/plugins/select2/select2.css'); ?>
<?php echo link_tag('assets/global/plugins/bootstrap-datepicker/css/datepicker3.css'); ?>
<!--?php echo link_tag('assets/admin/pages/css/profile.css'); ?-->
<!--?php echo link_tag('assets/global/plugins/jquery-multi-select/css/multi-select.css'); ?-->

<?php echo link_tag('assets/global/plugins/jquery-notific8/jquery.notific8.min.css'); ?>
<?php echo link_tag('assets/global/css/components-rounded.css'); ?>
<?php echo link_tag('assets/global/css/plugins.css'); ?>
<?php echo link_tag('assets/admin/layout3/css/layout.css'); ?>
<link id="style_color"  rel="stylesheet" type="text/css" href="<?php echo base_url('assets/admin/layout3/css/themes/default.css'); ?>">
<?php echo link_tag('assets/admin/layout3/css/custom.css'); ?>
<?php echo link_tag('assets_noondev/css/custom.css'); ?>
<!-- END THEME STYLES -->

