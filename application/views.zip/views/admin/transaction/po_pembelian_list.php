<style type="text/css">
.ppn{
	color: blue;
	display: none;
	font-weight: bold;
}

.no-ppn{
	color: red;
	display: none;
	font-weight: bold;
}

</style>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css'); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/extensions/ColReorder/css/dataTables.colReorder.min.css'); ?>"/>
<script src="<?php echo base_url('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>

<div class="page-content">
	<div class='container'>
		
		<div class="modal fade" id="portlet-config-kurs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=$common_data['controller_main'].'/po_pembelian_insert';?>" class="form-horizontal" id="form_add_data" method="post" target="_blank">
							<h3 class='block'>PO Pembelian <span class='ppn'>PPN</span> <span class='no-ppn'>NO PPN</span> </h3>
			                <div class="form-group">
			                    <label class="control-label col-md-3">Mata Uang<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6 radio-list">
		                    		<input hidden='hidden' name='po_type' value=''>
			                    	<?
			                    	foreach ($currency_type as $row) { ?>
				                    	<label>
				                    	<input type="radio" name="currency_type_id" value="<?=$row->id;?>"/><?=$row->nama.' - '.$row->simbol;?></label>
			                    	<? } ?>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name="tanggal" class='form-control date-picker' value="<?=date('d/m/Y');?>"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Supplier<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select class='form-control' name='supplier_id'>
	                    				<?foreach ($supplier_list_aktif as $row) { ?>
	                    					<option value="<?=$row->id;?>"><?=$row->nama;?></option>
	                    				<?}?>
	                    			</select>
			                    </div>
			                </div>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn blue btn-save">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="modal fade" id="portlet-config-import" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=$common_data['controller_main'].'/po_pembelian_insert';?>" class="form-horizontal" id="form_add_import" method="post" target="_blank">
							<h3 class='block'>PO Pembelian <b>IMPORT</b> </h3>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<input hidden='hidden' name='po_type' value='import'>
			                    	<input hidden='hidden' name="currency_type_id" value='2'>
	                    			<input name="tanggal" class='form-control date-picker' value="<?=date('d/m/Y');?>"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Supplier<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select class='form-control' name='supplier_id'>
	                    				<?foreach ($supplier_list_aktif as $row) { ?>
	                    					<option value="<?=$row->id;?>"><?=$row->nama;?></option>
	                    				<?}?>
	                    			</select>
			                    </div>
			                </div>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn blue btn-save-import">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="modal fade" id="portlet-config-edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=$common_data['controller_main'].'/po_pembelian_update';?>" class="form-horizontal" id="form_edit_data" method="post">
							<h3 class='block'> Pembelian <span class='ppn'>PPN</span> <span class='no-ppn'>NO PPN</span> </h3>
			                <div class="form-group">
			                    <label class="control-label col-md-3">Mata Uang<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6 radio-list">
			                    	<input name='po_type' value='' hidden='hidden'>
		                    		<input name='id' hidden='hidden' value=''>
			                    	<?
			                    	foreach ($currency_type as $row) { ?>
				                    	<label>
				                    	<input type="radio" name="currency_type_id" value="<?=$row->id;?>"/><?=$row->nama.' - '.$row->simbol;?></label>
			                    	<? } ?>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name="tanggal" class='form-control date-picker' value="<?=date('d/m/Y');?>"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Supplier<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select class='form-control' name='supplier_id'>
	                    				<?foreach ($supplier_list_aktif as $row) { ?>
	                    					<option value="<?=$row->id;?>"><?=$row->nama;?></option>
	                    				<?}?>
	                    			</select>
			                    </div>
			                </div>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn blue btn-edit-save">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="row margin-top-10">
			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase"><?=$breadcrumb_small;?></span>
							<select class='btn btn-xs btn-default' name='po_type' id='po_type_select'>
								<option value="" selected>All</option>
								<option value="0">PPN</option>
								<option value="1">NO PPN</option>
								<option value="2">IMPORT</option>
							</select>
						</div>
						<div class="actions">
							<select class='btn btn-sm btn-default' name='status_aktif_select' id='status_aktif_select'>
								<option value="1" selected>Aktif</option>
								<option value="0">Tidak Aktif</option>
							</select>
							<!-- <a href="#portlet-config" data-toggle='modal' class="btn btn-default btn-sm btn-form-add">
							<i class="fa fa-plus"></i> Tambah </a> -->

							<div class="btn-group">
								<a class="btn btn-default btn-sm" href="#" data-toggle="dropdown">
								<i class="fa fa-plus"></i> Tambah <i class="fa fa-angle-down"></i>
								</a>
								<ul class="dropdown-menu pull-right">
									<li>
										<a href="#portlet-config-kurs" data-toggle='modal' class='btn-ppn'>
										PPN </a>
									</li>
									<li>
										<a href="#portlet-config-kurs" data-toggle='modal' class='btn-no-ppn'>
										No PPN </a>
									</li>
									<li>
										<a href="#portlet-config-import" data-toggle='modal'>
										Import </a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="portlet-body">
						<table class="table table-striped table-bordered table-hover" id="general_table">
							<thead>
								<tr>
									<th scope="col" class='status_column'>
										Status Aktif
									</th>
									<th scope="col">
										PO Number
									</th>
									<th scope="col">
										Tanggal
									</th>
									<th scope="col">
										Supplier
									</th>
									<th scope="col">
										KURS
									</th>
									<th scope="col" style="min-width:150px !important">
										Actions
									</th>
									<th scope="col" class='status_column'>
										PO Type
									</th>
								</tr>
							</thead>
							<tbody>
								<?/*foreach ($po_pembelian_ppn_list as $row) { ?>
									<tr>
										<td>
											<span class='id' hidden="hidden"><?=$row->id;?></span>
											<span class='po_number'><?=$row->po_number;?></span> 
										</td>
										<td>
											<span class='tanggal'><?=implode('/', array_reverse(explode('-', $row->tanggal)));?></span> 
										</td>
										<td>
											<span class='supplier_id' hidden='hidden'><?=$row->supplier_id;?></span>
											<?=$row->nama_supplier;?> 
										</td>
										<td>
											<span class='currency_type_id' hidden='hidden'><?=$row->currency_type_id;?></span>
											<?=$row->simbol;?>
										</td>
										<td>
											<a href='#portlet-config-edit' data-toggle='modal' class="btn-xs btn green btn-edit"><i class="fa fa-edit"></i></a>
										</td>
									</tr>
								<? }*/ ?>

							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>			
</div>

<?php echo link_tag('assets/global/plugins/bootstrap-datepicker/css/datepicker3.css'); ?>
<script src="<?php echo base_url('assets/global/plugins/datatables/media/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/extensions/ColReorder/js/dataTables.colReorder.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets_noondev/js/table-advanced.js'); ?>"></script>

<script>
jQuery(document).ready(function() {

	// TableAdvanced.init();

	// oTable = $('#general_table').DataTable();
	// oTable.state.clear();
	// oTable.destroy();


	$("#general_table").DataTable({
   		"fnCreatedRow": function( nRow, aData, iDataIndex ) {
   			var romani = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
            var status_aktif = $('td:eq(0)', nRow).text();
            var tanggal = date_formatter($('td:eq(2)', nRow).text());
            var temp = tanggal.split('/');
            var po_n = $('td:eq(1)', nRow).text().split('??');
            var pcs1 = po_n[0];
            var pcs2 = romani[parseInt(temp[1]) - 1];
            var pcs3 = temp[2];
            
            if (po_n[1]=='0') {
            	var type = 'ppn';
            }else if (po_n[1]=='1') {
            	pcs3 = 'NP/'+pcs3;
            	var type = 'noppn';
            }else if (po_n[1]=='2') {
            	pcs3 = 'I/'+pcs3;
            	var type = 'import';
            };
            

            var po_data = $('td:eq(5)', nRow).text().split('??');
            var id = "<span hidden='hidden' class='id' >"+po_data[0]+"</span>";
            var supplier_id = "<span hidden='hidden' class='supplier_id' >"+po_data[1]+"</span>";
            var currency_type_id = "<span hidden='hidden' class='currency_type_id' >"+po_data[2]+"</span>";

            if (status_aktif == 1 ) {
            	var btn_status = "<a class='btn-xs btn red btn-remove'><i class='fa fa-times'></i> </a>";
            }else{
            	var btn_status = "<a class='btn-xs btn blue btn-remove'><i class='fa fa-play'></i> </a>";
            };

            var po_type = "<span hidden='hidden' class='po_type' >"+type+"</span>";
            // var btn_view = '<a href="transaction/po_pembelian_view?id='+po_data[0]+'&po_type=ppn" target="_blank" class="btn btn-xs yellow-gold"><i class="fa fa-search"></i></a>';
            var btn_view = '<a href="transaction/po_pembelian_view?id='+po_data[0]+'&po_type='+type+'" class="btn btn-xs yellow-gold" onclick="window.open(this.href, \'newwindow\', \'width=1050, height=750\'); return false;"><i class="fa fa-search"></i></a>';
           	var action = id+supplier_id+currency_type_id+"<a href='#portlet-config-edit' data-toggle='modal' class='btn-xs btn green btn-edit'><i class='fa fa-edit'></i> </a> "+btn_view+" "+btn_status+po_type;
           	// action += '<a href="http://www.facebook.com/sharer" onclick="window.open(this.href, \'mywin\',\'left=20,top=20,width=500,height=500,toolbar=1,resizable=0\'); return false;" >Share this</a>';

            $('td:eq(0)', nRow).html("<span class='status_aktif'>"+$('td:eq(0)', nRow).text()+'</span>');
            $('td:eq(0)', nRow).addClass('status_column');
            $('td:eq(1)', nRow).html('<span class="nama">'+pcs1+'</span>/'+pcs2+'/'+pcs3);
            $('td:eq(2)', nRow).html('<span class="tanggal">'+tanggal+'</span>');
            $('td:eq(5)', nRow).html(action);
            $('td:eq(6)', nRow).html('<span class="po_type">'+$('td:eq(6)', nRow).text()+'</span>');
            $('td:eq(6)', nRow).addClass('status_column');
            // $(nRow).addClass('status_aktif_'+status_aktif);
            
        },
        "bStateSave" :true,
		"bProcessing": true,
		"bServerSide": true,
		"sAjaxSource": baseurl + "transaction/po_pembelian_ppn"
	});

	var oTable;
    oTable = $('#general_table').dataTable();
    oTable.fnFilter( 1, 0 );

    $('#status_aktif_select').change(function(){
		oTable.fnFilter( $(this).val(), 0 ); 
	});

	$('#po_type_select').change(function(){
		// alert($(this).val());
		oTable.fnFilter( $(this).val(), 6 ); 
	});

	$('.btn-ppn').click(function(){
		$('.no-ppn').hide();
		$('.ppn').show();
		$('#form_add_data [name=po_type]').val('ppn');
	});

	$('.btn-no-ppn').click(function(){
		$('.ppn').hide();
		$('.no-ppn').show();
		$('#form_add_data [name=po_type]').val('noppn');
	});
	
	
   	$('#general_table').on('click', '.btn-edit', function(){
   		$('#form_edit_data [name=id]').val($(this).closest('tr').find('.id').html());
   		$('#form_edit_data [name=tanggal]').val($(this).closest('tr').find('.tanggal').html());
   		$('#form_edit_data [name=supplier_id]').val($(this).closest('tr').find('.supplier_id').html());
   		$('#form_edit_data [name=po_type]').val($(this).closest('tr').find('.po_type').html());
   		var currency_type_id = $(this).closest('tr').find('.currency_type_id').html();
   		// alert(currency_type_id);

   		$("#form_edit_data [name=currency_type_id][value="+currency_type_id+"]").prop("checked", true);
   		$.uniform.update($("#form_edit_data [name=currency_type_id]"));
   		// alert($('#form_add_data [name=currency_type_id]:checked').val());
   		
   	});

   	$('.btn-save').click(function(){
   		var terms = 0;
   		var currency_type_id = $('#form_add_data [name=currency_type_id]').is(':checked');
   		if( currency_type_id == '' || currency_type_id == false ){
   			notific8('ruby', 'Mata uang harus dipilih ! ');
   		}else{terms++;}

   		if ($('#form_add_data [name=tanggal]').val() == '') {
   			notific8('ruby', 'Tanggal tidak boleh kosong ! ');
   		}else{terms++;};

		if ($('#form_add_data [name=supplier_id]').val() == '') {
   			notific8('ruby', 'Supplier harus diisi ! ');
   		}else{terms++};

   		// alert(terms);

   		if(terms == 3){
   			$('#form_add_data').submit();
   			$('#portlet-config').modal('toggle');
   			setTimeout(function(){
   				window.location.reload();
   			},500); 
   		}
   	});

   	$('.btn-save-import').click(function(){
   		var terms = 1;
   		
   		if ($('#form_add_import [name=tanggal]').val() == '') {
   			notific8('ruby', 'Tanggal tidak boleh kosong ! ');
   		}else{terms++;};

		if ($('#form_add_data [name=supplier_id]').val() == '') {
   			notific8('ruby', 'Supplier harus diisi ! ');
   		}else{terms++};
   		// alert(terms);

   		if(terms == 3){
   			$('#form_add_import').submit();
   			$('#portlet-config').modal('toggle');
   			setTimeout(function(){
   				window.location.reload();
   			},500); 
   		}
   	});


 	

	$('.btn-edit-save').click(function(){
   		var terms = 0;
   		var currency_type_id = $('#form_edit_data [name=currency_type_id]').is(':checked');
   		if( currency_type_id == '' || currency_type_id == false ){
   			notific8('ruby', 'Mata uang harus dipilih ! ');
   		}else{terms++;}

   		if ($('#form_edit_data [name=tanggal]').val() == '') {
   			notific8('ruby', 'Tanggal tidak boleh kosong ! ');
   		}else{terms++;};

		if ($('#form_edit_data [name=supplier_id]').val() == '') {
   			notific8('ruby', 'Supplier harus diisi ! ');
   		}else{terms++};

   		// alert(terms);

   		if(terms == 3){$('#form_edit_data').submit();}
   	});

   	// $('.btn-edit-save').click(function(){
   	// 	if( $('#form_edit_data [name=nama]').val() != ''){
   	// 		$('#form_edit_data').submit();
   	// 	}
   	// });

   	$('#general_table').on('click', '.btn-remove', function(){
   		var po_type = $(this).closest('tr').find('.po_type').html();
   		var data = status_aktif_get($(this).closest('tr'))+'=?=po_pembelian_'+po_type;
   		// alert(data);
   		window.location.replace("transaction/ubah_status_aktif_po?data_sent="+data+'&link=po_pembelian_list');
   	});
});
</script>
