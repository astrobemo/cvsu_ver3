<script>

function print_faktur(printer_name){
	

	// if (idx == 1) {
	// 	qz.websocket.connect().then(function() {
	// 	});
	// };

	// var config = qz.configs.create("Nota");             // Exact printer name from OS
  	var data = ['\x1B' + '\x40'+          // init
	   	'\x1B' + '\x21' + '\x39'+ // em mode on
	   	<?="'".sprintf('%-20.18s','FAKTUR PENJUALAN')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%44.27s', 'BANDUNG, '.$tanggal_print)."'";?> + '\x0A'+

	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-40.30s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%36.25s', 'Kepada Yth,')."'";?> + '\x0A'+

	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-40.30s', 'CV. PELITA ABADI ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%36.25s', $nama_customer )."'";?> + '\x0A'+


	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-30.30s', 'TAMIM NO. 53 BANDUNG ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+ //spacing
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%47.47s', ($alamat_keterangan != '' ? $alamat_keterangan : '-'))."'";?> + '\x0A'+

	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-30.30s', 'TELP: (022)4238165 ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+ //spacing
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%47.47s','')."'";?> + '\x0A'+

   		'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-30.30s', 'FAX: (022)4218628 ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+ //spacing
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%47.47s', $kota)."'";?> + '\x0A'+


	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf("%'-80s", '')."'";?>+ '\x0A'+
	   	
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-30.30s', ($po_number != '' ? $po_number : '') )."'";?>+
	   	'\x1B' + '\x21' + '\x15'+ //spacing
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%47.47s', 'INVOICE NO : '.$no_faktur_lengkap)."'";?> + '\x0A'+


	   	//==============================================================================
	   	<?="'".sprintf("%'=80s", '')."'";?>+ '\x0A'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-6.6s', 'Jumlah ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-6.6s', 'Satuan ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-4.4s', 'Roll ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-27.27s', 'Nama Barang ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-8.8s', 'Harga ')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-13.13s', 'TOTAL ')."'";?> + '\x0A'+
	   	<?="'".sprintf("%'=80s", '')."'";?>+ '\x0A'+
		

	   	//==============================================================================
	   	<?
	   	$total = 0; $total_roll = 0; $idx = 0;
	   	foreach ($penjualan_print as $row) {
	   		$total += $row->qty * $row->harga_jual;
	   		$total_roll += $row->jumlah_roll;?>
	   			'\x1B' + '\x21' + '\x18'+ // em mode on
			   	<?="'".sprintf('%-6.6s', is_qty_general($row->qty))."'";?>+
			   	'\x1B' + '\x21' + '\x15'+
			   	'\x09'+
			   	'\x1B' + '\x21' + '\x18'+ // em mode on
			   	<?="'".sprintf('%-6.6s', $row->nama_satuan)."'";?>+
			   	'\x1B' + '\x21' + '\x15'+
			   	'\x09'+
			   	'\x1B' + '\x21' + '\x18'+ // em mode on
			   	<?="'".sprintf('%-4.4s', $row->jumlah_roll)."'";?>+
			   	'\x1B' + '\x21' + '\x15'+
			   	'\x09'+
			   	'\x1B' + '\x21' + '\x18'+ // em mode on
			   	<?="'".sprintf('%-27.27s', $row->nama_barang)."'";?>+
			   	'\x1B' + '\x21' + '\x15'+
			   	'\x09'+
			   	'\x1B' + '\x21' + '\x18'+ // em mode on
			   	<?="'".sprintf('%-8.8s', number_format($row->harga_jual,'0',',','.'))."'";?>+
			   	'\x1B' + '\x21' + '\x15'+
			   	'\x09'+
			   	'\x1B' + '\x21' + '\x18'+ // em mode on
			   	<?="'".sprintf('%13.13s', number_format($row->qty*$row->harga_jual,'0',',','.'))."'";?> + '\x0A'+
	   	<?$idx++;}?>
	   	<?for ($i = $idx; $i < 10; $i++) {?>
	   		'\x0A'+
	   	<?};?>
	   	<?="'".sprintf("%'=80s", '')."'";?>+ '\x0A'+
		
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%12.12s', 'TOTAL ROLL')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%4.4s', $total_roll)."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-27.27s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%8.8s', 'TOTAL')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%13.13s', number_format($total,'0',',','.'))."'";?> + '\x0A'+

	   	//==============================================================================

	   	<?foreach ($data_pembayaran as $row) {?>
		   	'\x1B' + '\x21' + '\x18'+ // em mode on
		   	<?="'".sprintf('%12.6s', '')."'";?>+
		   	'\x1B' + '\x21' + '\x15'+
		   	'\x09'+
		   	'\x1B' + '\x21' + '\x18'+ // em mode on
		   	<?="'".sprintf('%4.4s', '')."'";?>+
		   	'\x1B' + '\x21' + '\x15'+
		   	'\x09'+
		   	'\x1B' + '\x21' + '\x18'+ // em mode on
		   	<?="'".sprintf('%-27.27s', '')."'";?>+
		   	'\x1B' + '\x21' + '\x15'+
		   	'\x09'+
		   	'\x1B' + '\x21' + '\x18'+ // em mode on
		   	<?="'".sprintf('%8.8s', $row->nama_bayar)."'";?>+
		   	'\x1B' + '\x21' + '\x15'+
		   	'\x09'+
		   	'\x1B' + '\x21' + '\x18'+ // em mode on
		   	<?="'".sprintf('%13.13s', number_format($row->amount,'0',',','.'))."'";?> + '\x0A'+
	   	<?}?>

	   	//==============================================================================

	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%12.6s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%4.4s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-27.27s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf("%'-28s",'')."'";?> + '\x0A'+

	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%12.6s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%4.4s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%-27.27s', '')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf("%8.8s",'KEMBALI')."'";?>+
	   	'\x1B' + '\x21' + '\x15'+
	   	'\x09'+
	   	'\x1B' + '\x21' + '\x18'+ // em mode on
	   	<?="'".sprintf('%13.13s', number_format($kembali,'0',',','.'))."'";?> + '\x0A'+
	   	'\x1B' + '\x21' + '\x04'+ // em mode on
	   	<?="'".sprintf('%125.125s', '*harga sudah termasuk ppn')."'";?> + '\x0A'+
	   	'\x0A'+
	   	'\x0A'+
	   	<?
			echo "'".sprintf('%-18.14s %-5.5s %-15.15s %-15.15s ', 'Tanda Terima', '', 'Checker', 'Hormat Kami')."'";?> + '\x0A'+<?
	   	?>
	   	

	   	/*
	   	<?
			echo "'".sprintf('%-15.12s %-4.4s %-31.30s %-12.11s %-12.11s ', 'TOTAL ROLL', $total_roll, '', 'Total*', number_format($total,'0',',','.'))."'";?> + '\x0A'+<?
	   	?>		   	
	   	<?="'".sprintf("%'=80s", '')."'";?>+ '\x0A'+
	  	'\x0A',
		*/
	   	'\x1B' + '\x69',          // cut paper
	   	'\x10' + '\x14' + '\x01' + '\x00' + '\x05',  // Generate Pulse to kick-out cash drawer**
	                                                // **for legacy drawer cable CD-005A.  Research before using.
	                                                // see also http://keyhut.com/popopen4.htm
    ];
	// console.log(data);

    webprint.printRaw(data, printer_name);


	// qz.print(config, data).then(function() {
	//    // alert("Sent data to printer");
	// });
}

</script>