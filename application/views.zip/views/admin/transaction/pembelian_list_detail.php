<link href="<?=base_url('assets/global/plugins/bootstrap-modal/css/bootstrap-modal.css');?>" rel="stylesheet" type="text/css"/>
<?=link_tag('assets/global/plugins/bootstrap-datepicker/css/datepicker3.css'); ?>


<div class="page-content">
	<div class='container'>

		<?
			$pembelian_id = '';
			$supplier_id = '';
			$nama_supplier = '';
			$gudang_id = '';
			$nama_gudang = '';
			$no_faktur = '';
			$ockh = '';
			$tanggal = '';
			$ori_tanggal = '';
			$toko_id = '';
			$nama_toko = '';
			
			$jatuh_tempo = '';
			$ori_jatuh_tempo = '';
			$diskon = 0;
			$status = 0;
			$status_aktif = 0;
			$keterangan = '';

			foreach ($pembelian_data as $row) {
				$pembelian_id = $row->id;
				$supplier_id = $row->supplier_id;
				$nama_supplier = $row->nama_supplier;
				$gudang_id = $row->gudang_id;
				$nama_gudang = $row->nama_gudang;
				$no_faktur = $row->no_faktur;
				$ockh = $row->ockh;
				$tanggal = is_reverse_date($row->tanggal);
				$ori_tanggal = $row->tanggal;
				$toko_id = $row->toko_id;
				$nama_toko = $row->nama_toko;
				
				$jatuh_tempo = is_reverse_date($row->jatuh_tempo);
				$ori_jatuh_tempo = $row->jatuh_tempo;

				$diskon = $row->diskon;
				$status = $row->status;
				$status_aktif = $row->status_aktif;
				$keterangan = $row->keterangan;
			}

			$readonly = ''; $disabled = '';
			if (is_posisi_id() == 6) {
				$readonly = 'readonly';
				$disabled = 'disabled';
			}
		?>


		<div class="modal fade" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('transaction/pembelian_list_insert')?>" class="form-horizontal" id="form_add_data" method="post">
							<h3 class='block'> Pembelian Baru</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">Supplier<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<select class='input1 form-control supplier-input' style='font-weight:bold' name="supplier_id">
			                    		<?foreach ($this->supplier_list_aktif as $row) { ?>
			                    			<option <?=($row->id==1 ? 'selected' : '');?> value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div>			                

			                <div class="form-group">
			                    <label class="control-label col-md-3">Gudang<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select style='font-weight:bold' class='form-control gudang-input' name="gudang_id">
			                    		<?foreach ($this->gudang_list_aktif as $row) { ?>
			                    			<option <?=($row->id==2 ? 'selected' : '');?> value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
					                <input type="text" readonly class="form-control date-picker" value="<?=date('d/m/Y');?>" name="tanggal"/>
			                    </div>
			                </div> 	

			                <div class="form-group">
			                    <label class="control-label col-md-3">No Faktur<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class="form-control" name="no_faktur"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">OCKH
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class='form-control' name="ockh"/>
			                    </div>
			                </div>   


			                <div class="form-group">
			                    <label class="control-label col-md-3">Toko
			                    </label>
			                    <div class="col-md-6">
					                <select name="toko_id" class='form-control'>
			                    		<?foreach ($this->toko_list_aktif as $row) { ?>
			                    			<option value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select> 
			                    </div>
			                </div>
						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-active btn-trigger btn-save">Save</button>
						<button type="button" class="btn default  btn-active" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
		<div class="modal fade" id="portlet-config-edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('transaction/pembelian_list_update')?>" class="form-horizontal" id="form_edit_data" method="post">
							<h3 class='block'> Edit Data</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">Supplier<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" name="pembelian_id" value='<?=$pembelian_id;?>' hidden='hidden'/>
			                    	<select class='input1 form-control supplier-input' style='font-weight:bold' name="supplier_id">
			                    		<?foreach ($this->supplier_list_aktif as $row) { ?>
			                    			<option <?if ($supplier_id == $row->id) {echo 'selected';}?> value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div>			                

			                <div class="form-group">
			                    <label class="control-label col-md-3">Gudang<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select style='font-weight:bold' class='form-control gudang-input' name="gudang_id">
			                    		<?foreach ($this->gudang_list_aktif as $row) { ?>
			                    			<option <?if ($gudang_id == $row->id) {echo 'selected';}?> value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
					                <input type="text" readonly class="form-control date-picker" value="<?=$tanggal;?>" name="tanggal"/>
			                    </div>
			                </div> 	

			                <div class="form-group">
			                    <label class="control-label col-md-3">No Faktur<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class="form-control" name="no_faktur" value="<?=$no_faktur;?>"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">OCKH
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class='form-control' name="ockh" value="<?=$ockh?>"/>
			                    </div>
			                </div>   


			                <div class="form-group">
			                    <label class="control-label col-md-3">Toko
			                    </label>
			                    <div class="col-md-6">
					                <select name="toko_id" class='form-control'>
			                    		<?foreach ($this->toko_list_aktif as $row) { ?>
			                    			<option <?if ($toko_id == $row->id) {echo 'selected';}?> value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select> 
			                    </div>
			                </div>
						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-active btn-trigger btn-edit-save">Save</button>
						<button type="button" class="btn default btn-active" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="modal fade" id="portlet-config-detail" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('transaction/pembelian_list_detail_insert')?>" class="form-horizontal" id="form_add_barang" method="post">
							<h3 class='block'> Tambah Barang</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">Kode Barang<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<input name='pembelian_id' value='<?=$pembelian_id;?>' hidden='hidden'>
			                    	<select name="barang_id" class='form-control input1' id='barang_id_select'>
		                				<option value=''>Pilih</option>
		                				<?foreach ($this->barang_list_aktif as $row) { ?>
			                    			<option value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    	<select name='data_barang' hidden='hidden'>
			                    		<?foreach ($this->barang_list_aktif as $row) { ?>
			                    			<option value="<?=$row->id?>"><?=$row->nama_satuan;?>??<?=$row->harga_beli;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div>			                

			                <div class="form-group">
			                    <label class="control-label col-md-3">Warna<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select name="warna_id" class='form-control' id='warna_id_select'>
		                				<option value=''>Pilihan..</option>
			                    		<?foreach ($this->warna_list_aktif as $row) { ?>
			                    			<option value="<?=$row->id?>"><?=$row->warna_beli;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Satuan<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
		                			<input readonly type="text" class='form-control' name="satuan"/>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Harga Beli<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
		                			<input type="text" class='amount_number form-control' name="harga_beli"/>
			                    </div>
			                </div> 	

			                <div class="form-group">
			                    <label class="control-label col-md-3">Qty <span class='satuan_unit'></span> <span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class="form-control" name="qty"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Jumlah Roll
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class='form-control' name="jumlah_roll"/>
			                    </div>
			                </div>   
						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-active btn-trigger btn-save-brg">Save</button>
						<button type="button" class="btn default btn-active" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="modal fade" id="portlet-config-faktur" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url().trim(base64_encode('transaction/pembelian_list_detail'));?>" class="form-horizontal" id="form_search_faktur" method="post">
							<h3 class='block'> Cari Faktur</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">No Faktur<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
									<input type="hidden" name='pembelian_id' id="search_no_faktur" class="form-control select2">
			                    </div>
			                </div>	
		                </form>		                
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-search-faktur">GO!</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		
		<div class="row margin-top-10">
			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase"><?=$breadcrumb_small;?></span>
						</div>
						<div class="actions">
							<?if (is_posisi_id() != 6) { ?>
								<a href="#portlet-config" data-toggle='modal' class="btn btn-default btn-sm btn-form-add">
								<i class="fa fa-plus"></i> Pembelian Baru </a>
							<?}?>
							<a href="#portlet-config-faktur" data-toggle='modal' class="btn btn-default btn-sm btn-form-add">
							<i class="fa fa-search"></i> Cari Faktur </a>
						</div>
					</div>
					<div class="portlet-body">
						<table>
							<?if ($pembelian_id != '') { ?>
								<tr>
									<td colspan='3'>
										<?if (is_posisi_id() != 6) { ?>
											<button href="#portlet-config-edit" data-toggle='modal' class='btn btn-xs '><i class='fa fa-edit'></i> edit</button>
										<?}?>
									</td>
								</tr>
							<?}?>
							<tr>
					    		<td>No Faktur</td>
					    		<td class='padding-rl-5'> : </td>
					    		<td class='td-isi-bold'>
					    			<?=$no_faktur;?>
					    		</td>
					    	</tr>
					    	<tr>
					    		<td>OCKH</td>
					    		<td class='padding-rl-5'> : </td>
					    		<td  class='td-isi-bold'>
					    			<?=$ockh;?></td>
					    	</tr>
					    	<tr>
					    		<td>Tanggal</td>
					    		<td class='padding-rl-5'> : </td>
					    		<td class='td-isi-bold'><?=$tanggal;?></td>
					    	</tr>
					    	<tr>
					    		<td>Toko</td>
					    		<td class='padding-rl-5'> : </td>
					    		<td class='td-isi-bold'>
					    			<?=$nama_toko;?>
					    		</td>
					    	</tr>
					    	<tr>
						    	<td>Gudang</td>
					    		<td class='padding-rl-5'> : </td>
					    		<td class='td-isi-bold'>
					    			<?=$nama_gudang;?>
					            </td>
				            </tr>
					    	<tr>
					    		<td>Supplier</td>
					    		<td class='padding-rl-5'> : </td>
					    		<td class='td-isi-bold'>
					    			<?=$nama_supplier;?>
					    		</td>
					    	</tr>

					    	
					    </table>

					    <hr/>
						<!-- table-striped table-bordered  -->
						<table class="table table-hover table-striped table-bordered" id="general_table">
							<thead>
								<tr>
									<th scope="col">
										No
									</th>
									<th scope="col">
										Nama Barang
										<?if ($pembelian_id != '' && is_posisi_id() !=6) { ?>
											<a href="#portlet-config-detail" data-toggle='modal' class="btn btn-xs blue btn-brg-add">
											<i class="fa fa-plus"></i> </a>
										<?}?>
									</th>
									<th scope="col">
										Satuan
									</th>
									<th scope="col">
										Jml Yard/KG
									</th>
									<th scope="col">
										Jml Roll
									</th>
									<th scope="col">
										Harga
									</th>
									<th scope="col">
										Total Harga
									</th>
									<th scope="col">
										Action
									</th>
								</tr>
							</thead>
							<tbody>
								<?
								$i =1; $g_total = 0;
								foreach ($pembelian_detail as $row) { ?>
									<tr>
										<td>
											<span class='id' hidden="hidden"><?=$row->id;?></span>
											<?=$i;?> 
										</td>
										<td>
											<span class='nama_jual'><?=$row->nama_barang;?> <?=$row->nama_warna;?></span> 
										</td>
										<td>
											<?=$row->nama_satuan;?>
										</td>
										<td>
											<input name='qty' <?=$readonly;?> class='free-input-sm qty' value="<?=$row->qty;?>"> 
										</td>
										<td>
											<input name='jumlah_roll' <?=$readonly;?> class='free-input-sm jumlah_roll' value="<?=$row->jumlah_roll;?>">
										</td>
										<td>
											<input name='harga_beli' <?=$readonly;?> class='free-input-sm amount_number harga_beli' value="<?=number_format($row->harga_beli,'0','.','.');?>"> 
										</td>
										<td>
											<?$subtotal = $row->qty * $row->harga_beli;
											$g_total += $subtotal;
											?>
											<span <?=$readonly;?> class='subtotal'><?=number_format($subtotal,'0','.','.');?></span> 
										</td>
										<td>
											<?if(is_posisi_id() != 6){?>
												<a class="btn-xs btn red btn-detail-remove"><i class="fa fa-times"></i> </a>
											<?} ?>
											<!-- <a href='#portlet-config-edit' data-toggle='modal' class="btn-xs btn green btn-edit"><i class="fa fa-edit"></i> </a> -->
										</td>
									</tr>
								<? $i++;} ?>
							</tbody>
						</table>

						<table style='width:100%'>
							<tr>
								<td>
									<table>
										<tr>
											<td>Subtotal</td>
											<td class='padding-rl-5'> : </td>
								    		<td class='td-isi-bold'><span class='total'><?=number_format($g_total,'0',',','.');?></span> </td>
										</tr>
										<tr>
											<td>Diskon</td>
											<td class='padding-rl-5'> : </td>
								    		<td class='td-isi-bold'><input <?=$readonly;?> <?if ($pembelian_id =='') {?>readonly<?}?> name='diskon' class='amount_number padding-rl-5 diskon' value="<?=number_format($diskon,'0',',','.');?>"></td>
										</tr>
										<tr>
											<td>Jatuh Tempo</td>
											<td class='padding-rl-5'> : </td>
								    		<td class='td-isi-bold'>
								    			
								    			<?$style='';
								    			$diff = strtotime($ori_jatuh_tempo) - strtotime($ori_tanggal);
								    			$diff = $diff/(60*60*24);
								    			// echo $diff;
								    			if ($diff < 0) {
								    				$style = 'color:red';
								    			}?>
								    			<input name='jatuh_tempo'  <?=$readonly;?> <?if ($pembelian_id =='') {?>readonly<?}?> class="<?if ($pembelian_id !='' && is_posisi_id() != 6 ) {?>date-picker<?}?> padding-rl-5 jatuh_tempo" style='<?=$style;?>' value='<?=$jatuh_tempo;?>'></td>
										</tr>
										<tr>
											<td>Keterangan</td>
											<td class='padding-rl-5'> : </td>
								    		<td class='td-isi-bold'><input <?=$readonly;?> <?if ($pembelian_id =='' && is_posisi_id() != 6) {?>readonly<?}?> class='padding-rl-5 keterangan' name='keterangan' value="<?=$keterangan;?>"></td>
										</tr>
									</table>
								</td>
								<td style='vertical-align:top;font-size:4em;' class='text-right'>
									<b>Rp <span class='g_total' style=''><?=number_format($g_total - $diskon,'0',',','.');?></span></b>
								</td>
							</tr>

						</table>
						<hr/>
						<div>
			                <a class='btn btn-lg blue hidden-print'><i class='fa fa-print'></i> Print </a>

						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>			
</div>

<script src="<?php echo base_url('assets/global/plugins/bootbox/bootbox.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/bootstrap-modal/js/bootstrap-modalmanager.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/bootstrap-modal/js/bootstrap-modal.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/jquery-validation/js/jquery.validate.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets_noondev/js/form-pembelian.js'); ?>" type="text/javascript"></script>

<script src="<?php echo base_url('assets/global/plugins/select2/select2.min.js'); ?>" type="text/javascript" ></script>
<script>
jQuery(document).ready(function() {

	FormNewPembelian.init();
	FormEditPembelian.init();
	FormNewPembelianDetail.init();

	$('#barang_id_select').select2({
        placeholder: "Pilih...",
        allowClear: true
    });

    $('#warna_id_select').select2({
        placeholder: "Pilih...",
        allowClear: true
    });

    <?if ($pembelian_id != '' && is_posisi_id() != 6) { ?>
    	var map = {220: false};
		$(document).keydown(function(e) {
		    if (e.keyCode in map) {
		        map[e.keyCode] = true;
		        if (map[220]) {
		            $('#portlet-config-detail').modal('toggle');
		            setTimeout(function(){
		            	$('#barang_id_select').focus();
		            },600);
		        }
		    }
		}).keyup(function(e) {
		    if (e.keyCode in map) {
		        map[e.keyCode] = false;
		    }
		});
    <?}?>

    $('.btn-brg-add').click(function(){
    	// var select2 = $(this).data('select2');
    	setTimeout(function(){
    		$('#barang_id_select').select2("open");
    		// $('#form_add_barang .input1 .select2-choice').click();
    	},700);
    });

    $('#barang_id_select').change(function(){
    	var barang_id = $('#barang_id_select').val();
   		var data = $("#form_add_barang [name=data_barang] [value='"+barang_id+"']").text().split('??');
   		// alert(data);
		$('#form_add_barang [name=harga_beli]').val(change_number_format(data[1]));
		$('#form_add_barang .satuan_unit').html(data[0]+'/kg');
		$('#form_add_barang [name=satuan]').val(data[0]);
    });


    $('#general_table').on('change','.qty, .jumlah_roll,.harga_beli', function(){
    	var ini = $(this).closest('tr');
    	var data = {};
    	data['column'] = $(this).attr('name');
    	data['id'] =  ini.find('.id').html();
    	data['value'] = $(this).val();
    	var url = 'transaction/pembelian_detail_update';
    	// update_table(ini);
    	ajax_data_sync(url,data).done(function(data_respond  /*,textStatus, jqXHR*/ ){
			if (data_respond == 'OK') {
				var qty = ini.find('.qty').val();
				var harga_beli = reset_number_format(ini.find('.harga_beli').val());

				ini.find('.subtotal').html(change_number_format(qty*harga_beli));
				update_table();
			};
   		});
    });

    $('#general_table').on('click','.btn-detail-remove', function(){
	    var ini = $(this).closest('tr');
	    bootbox.confirm("Mau menghapus item ini ? ", function(respond){
	    	if (respond) {
	    		var data = {};
		    	data['id'] =  ini.find('.id').html();
		    	var url = 'transaction/pembelian_detail_remove';
		    	// update_table(ini);
		    	ajax_data_sync(url,data).done(function(data_respond  /*,textStatus, jqXHR*/ ){
					if (data_respond == 'OK') {
						ini.remove();
						update_table();
					};
		   		});
	    	};
	    });
    });

    <?if ($pembelian_id != '') { ?>
    	$(document).on('change','.diskon, .keterangan', function(){
	    	var ini = $(this).closest('tr');
	    	var data = {};
	    	data['column'] = $(this).attr('name');
	    	data['pembelian_id'] =  "<?=$pembelian_id;?>";
	    	data['value'] = $(this).val();
	    	var url = 'transaction/pembelian_data_update';
	    	// update_table(ini);
	    	ajax_data_sync(url,data).done(function(data_respond  /*,textStatus, jqXHR*/ ){
				if (data_respond == 'OK') {
					update_table(ini);
				};
	   		});
	    });

	    $(document).on('change','.jatuh_tempo', function(){
	    	var ini = $(this).closest('tr');
	    	var data = {};
	    	data['ori_tanggal'] = "<?=$ori_tanggal;?>";
	    	data['pembelian_id'] =  "<?=$pembelian_id;?>";
	    	data['jatuh_tempo'] = $(this).val();
	    	var url = 'transaction/pembelian_jatuh_tempo_update';
	    	// update_table(ini);
	    	ajax_data_sync(url,data).done(function(data_respond  /*,textStatus, jqXHR*/ ){
				// alert(data_respond);
				if (data_respond == 'OK') {
					$('.jatuh_tempo').css('color','black');
				}else{
					$('.jatuh_tempo').css('color','red');
				}
	   		});
	    });
    <?}?>

    $("#search_no_faktur").select2({
        placeholder: "Select...",
        allowClear: true,
        minimumInputLength: 1,
        query: function (query) {
            var data = {
                results: []
            }, i, j, s;
            var data_st = {};
			var url = "transaction/get_search_no_faktur";
			data_st['no_faktur'] = query.term;
			
			ajax_data_sync(url,data_st).done(function(data_respond  /*,textStatus, jqXHR*/ ){
				// console.log(data_respond);
				$.each(JSON.parse(data_respond),function(k,v){
					data.results.push({
	                    id: v.id,
	                    text: v.no_faktur
	                });
				});
	            query.callback(data);
	   		});
        }
    });

    $('.btn-search-faktur').click(function(){
    	var id = $("#form_search_faktur [name=pembelian_id]").val();
    	var action = $("#form_search_faktur").attr('action');
    	if (id != '') {
    		window.location.replace(action+'/'+id);
    	};
    });
});

function update_table(){
	subtotal = 0;
	$('.subtotal').each(function(){
		subtotal+= reset_number_format($(this).html());
	});

	$('.total').html(change_number_format(subtotal));
	var diskon = reset_number_format($('.diskon').val());
	var g_total = subtotal - parseInt(diskon);
	$('.g_total').html(change_number_format(g_total));

}
</script>
