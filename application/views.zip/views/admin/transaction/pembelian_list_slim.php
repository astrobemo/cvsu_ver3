<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css'); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/extensions/ColReorder/css/dataTables.colReorder.min.css'); ?>"/>
<link href="<?=base_url('assets/global/plugins/bootstrap-modal/css/bootstrap-modal.css');?>" rel="stylesheet" type="text/css"/>

<?=link_tag('assets/global/plugins/select2/select2.css'); ?>


<style type="text/css">


</style>
<div class="page-content">
	<div class='container'>

		<div id="pembelian-modal" class="modal fade" style='width:100%' tabindex="-1">
		</div>


		
		<div class="modal fade bs-modal-lg" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('transaction/pembelian_list_insert')?>" class="form-horizontal" id="form_add_data" method="post">
							<h3 class='block'> Pembelian Baru</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">Supplier<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<select class='input1 form-control supplier-input' style='font-weight:bold' name="supplier_id">
			                    		<?foreach ($this->supplier_list_aktif as $row) { ?>
			                    			<option <?=($row->id==1 ? 'selected' : '');?> value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div>			                

			                <div class="form-group">
			                    <label class="control-label col-md-3">Gudang<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select style='font-weight:bold' class='form-control gudang-input' name="gudang_id">
			                    		<?foreach ($this->gudang_list_aktif as $row) { ?>
			                    			<option <?=($row->id==2 ? 'selected' : '');?>  value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
					                <input type="text" readonly class="form-control date-picker" value="<?=date('d/m/Y');?>" name="tanggal"/>
			                    </div>
			                </div> 	

			                <div class="form-group">
			                    <label class="control-label col-md-3">No Faktur<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class="form-control" name="no_faktur"/>
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">OCKH
			                    </label>
			                    <div class="col-md-6">
			                		<input type="text" class='form-control' name="ockh"/>
			                    </div>
			                </div>   


			                <div class="form-group">
			                    <label class="control-label col-md-3">Toko
			                    </label>
			                    <div class="col-md-6">
					                <select name="toko_id" class='form-control'>
			                    		<?foreach ($this->toko_list_aktif as $row) { ?>
			                    			<option value="<?=$row->id?>"><?=$row->nama;?></option>
			                    		<? } ?>
			                    	</select> 
			                    </div>
			                </div>
						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-active btn-trigger blue btn-save">Save</button>
						<button type="button" class="btn  btn-active default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		
		<div class="row margin-top-10">
			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase"><?=$breadcrumb_small;?></span>
						</div>
						<div class="actions">
							<select class='btn btn-sm btn-default' name='status_select' id='status_select'>
								<option value="" selected>All</option>
								<option value="1">Aktif</option>
								<!-- <option value="0">Tidak Aktif</option> -->
								<option value="0">Batal</option>

							</select>

							<a href="#portlet-config" data-toggle='modal' class="btn btn-default btn-sm btn-form-add">
							<i class="fa fa-plus"></i> Tambah </a>
						</div>
					</div>
					<div class="portlet-body">
						<table class="table table-hover table-striped table-bordered" id="general_table">
							<thead>
								<tr>
									<th scope="col" class='status_column'>
										Status Aktif
									</th>
									<th scope="col">
										Toko
									</th>
									<th scope="col">
										No Faktur
									</th>
									<th scope="col">
										Tanggal Pembelian
									</th>
									<!-- <th scope="col">
										Satuan
									</th> -->
									<!-- <th scope="col">
										Yard/KG
									</th>
									<th scope="col">
										Jml Roll
									</th>
									<th scope="col">
										Nama Barang
									</th> -->
									<th scope="col">
										Gudang
									</th>
									<!-- <th scope="col">
										Harga
									</th> -->
									<th scope="col">
										Total
									</th>
									<th scope="col">
										Supplier
									</th>
									<th scope="col">
										Status
									</th>
									<th scope="col" >
										Actions
									</th>
								</tr>
							</thead>
							<tbody>
								
							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</div>			
</div>

<script src="<?php echo base_url('assets/global/plugins/bootstrap-modal/js/bootstrap-modalmanager.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/bootstrap-modal/js/bootstrap-modal.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/jquery-validation/js/jquery.validate.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/media/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets_noondev/js/table-advanced.js'); ?>"></script>
<script src="<?php echo base_url('assets/global/plugins/bootbox/bootbox.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets_noondev/js/form-pembelian.js'); ?>" type="text/javascript"></script>



<script src="<?php echo base_url('assets/global/plugins/select2/select2.min.js'); ?>" type="text/javascript" ></script>
<script src="<?php echo base_url('assets_noondev/js/ui-extended-modals.js'); ?>"></script>
<script>
jQuery(document).ready(function() {
	Metronic.init(); // init metronic core components
	Layout.init(); // init current layout
	// TableAdvanced.init();
	FormNewPembelian.init();
	ModalsPembelianEdit.init();
	$('.barang-id, .warna-id').select2({
        allowClear: true
    });

	// oTable = $('#general_table').DataTable();
	// oTable.state.clear();
	// oTable.destroy();

	$("#general_table").DataTable({
   		"fnCreatedRow": function( nRow, aData, iDataIndex ) {
            var status = $('td:eq(8)', nRow).text().split('??');
            var id = status[0];
            var toko_id = status[1];            
            var gudang_id = status[2];
            var supplier_id = status[3];
            var tanggal = date_formatter($('td:eq(3)', nRow).html());
            var total = $('td:eq(5)', nRow).text();
            
            var url = "<?=base_url().rtrim(base64_encode('transaction/pembelian_list_detail'),'=');?>/"+id;
            var url_print = "<?=base_url();?>transaction/pembelian_print?pembelian_id="+id;
            var button_edit = "<a href='"+url+"' class='btn-xs btn green btn-edit'><i class='fa fa-edit'></i> </a>";
            var button_view = '<a href="'+url_print+'" class="btn-xs btn blue btn-print" onclick="window.open(this.href, \'newwindow\', \'width=1250, height=650\'); return false;"><i class="fa fa-print"></i> </a>';
           	var button_remove = '';

           	var posisi_id = "<?=is_posisi_id();?>"
           	if (posisi_id != 6) {
           		var status_aktif = $('td:eq(0)', nRow).text();
           		if (status_aktif == 1) {
		           	button_remove = "<a class='btn-xs btn red btn-remove'><i class='fa fa-times'></i> </a>";
           		}else{
		           	button_remove = "<a class='btn-xs btn blue btn-activate'><i class='fa fa-play'></i> </a>";
           		}
           	};

           	var status_ket = $('td:eq(7)', nRow).text();
           	if (status_ket < 0) {
           		var status = "<span style='color:red'>belum lunas</span>";
           	}else{
           		var status = "<span style='color:blue'>lunas</span>";
           	}

           	if (status_aktif == 0) {
           		var status = "BATAL";
           	};
           	
           	var action = "<span class='id' hidden='hidden'>"+id+"</span><span class='toko_id' hidden='hidden'>"+toko_id+"</span><span class='gudang_id' hidden='hidden'>"+gudang_id+"</span><span class='supplier_id' hidden='hidden'>"+supplier_id+"</span>"+button_edit+button_remove + button_view;

            $('td:eq(0)', nRow).addClass('status_column');
            $('td:eq(1)', nRow).html('<span class="toko_id">'+$('td:eq(1)', nRow).text()+'</span>');
            $('td:eq(2)', nRow).html('<span class="no_faktur">'+$('td:eq(2)', nRow).text()+'</span>');
            $('td:eq(3)', nRow).html(tanggal);
            if ($('td:eq(5)', nRow).text() != '') {
            	var total = change_number_format2($('td:eq(5)', nRow).text());
            }else{
            	var total = 0
            }
            $('td:eq(5)', nRow).html('<span class="total">'+total+'</span>');
            if (total == 0 || total == '') {
	            $('td:eq(5)', nRow).addClass('caution');
            };
            
            $('td:eq(8)', nRow).html(action);
            $('td:eq(7)', nRow).html(status);


            
        },
        "bStateSave" :true,
		"bProcessing": true,
		"bServerSide": true,
		"sAjaxSource": baseurl + "transaction/data_pembelian_slim",
		"order":[[2, 'desc']]

	});

	// $("#general_table").DataTable({
 //   		"fnCreatedRow": function( nRow, aData, iDataIndex ) {
 //            var status = $('td:eq(11)', nRow).text().split('??');
 //            var id = status[0];
 //            var toko_id = status[1];            
 //            var gudang_id = status[2];
 //            var supplier_id = status[3];
 //            var tanggal = date_formatter($('td:eq(3)', nRow).html());
 //            var qty = $('td:eq(4)', nRow).text();
 //            var harga = $('td:eq(8)', nRow).text();
 //            var st =  $('td:eq(4)', nRow).text();
 //            satuan = st.replace('??','<br/>');

 //            var status = $('td:eq(11)', nRow).text();

 //            var ket = parseInt($('td:eq(11)', nRow).text());
 //            if (status == -1) {
 //            	var stat = "<span style='color:#000'>batal</span>";
 //            }else if (ket >= 0) {
 //            	var stat = "<span style='color:green'>lunas</span>";
 //            }else{
 //            	var stat = "<span style='color:red'>belum lunas</span>";
 //            }
 //            // href='#portlet-config-edit' data-toggle='modal'
 //            // var button_edit = "<button class='btn-xs btn green btn-edit'><i class='fa fa-edit'></i> </button>";
 //            var url = "<?=rtrim(base64_encode('transaction/pembelian_list_detail'),'=');?>/"+id;
 //            var button_edit = "<a href='"+url+"' class='btn-xs btn green btn-edit'><i class='fa fa-edit'></i> </a>";
 //           	var action = "<span class='id' hidden='hidden'>"+id+"</span><span class='toko_id' hidden='hidden'>"+toko_id+"</span><span class='gudang_id' hidden='hidden'>"+gudang_id+"</span><span class='supplier_id' hidden='hidden'>"+supplier_id+"</span>"+button_edit+"<a class='btn-xs btn red btn-remove'><i class='fa fa-times'></i> </a>";
 //            // var qty = $('td:eq(4)', nRow).html();
 //            var harga = $('td:eq(8)', nRow).html();
 //            // var total = change_number_format(qty * harga);

 //            $('td:eq(0)', nRow).addClass('status_column');
 //            $('td:eq(1)', nRow).html('<span class="toko_id">'+$('td:eq(1)', nRow).text()+'</span>');
 //            $('td:eq(2)', nRow).html('<span class="no_faktur">'+$('td:eq(2)', nRow).text()+'</span>');
 //            $('td:eq(3)', nRow).html(tanggal);
 //            $('td:eq(4)', nRow).html(satuan);
 //            $('td:eq(8)', nRow).html('<span class="harga">'+change_number_format(harga)+'</span>');
 //            $('td:eq(9)', nRow).html('<span class="total">'+change_number_format(qty*harga)+'</span>');
 //            $('td:eq(11)', nRow).html(stat);
 //            // $(nRow).addClass('test_pink')

 //            // $('td:eq(4)', nRow).html('<span class="harga_beli">'+change_number_format($('td:eq(4)', nRow).text())+'</span>');
 //            $('td:eq(12)', nRow).html(action);
            
 //        },
 //        "bStateSave" :true,
	// 	"bProcessing": true,
	// 	"bServerSide": true,
	// 	"sAjaxSource": baseurl + "transaction/data_pembelian"
	// });

	// $('.supplier-input, .gudang-input').click(function(){
	// 	$('#form_add_data .supplier-input').removeClass('supplier-input');
	// })


	var oTable;
    oTable = $('#general_table').dataTable();
    oTable.fnFilter( '', 0 );

	$('#status_select').change(function(){
		oTable.fnFilter( $(this).val(), 0 ); 
	});

	

   	$('.btn-edit-save').click(function(){
   		if( $('#form_edit_data [name=nama]').val() != ''){
   			$('#form_edit_data').submit();
   		}
   	});

   	$('#general_table').on('click','.btn-remove', function(){
		var ini = $(this).closest('tr');
		bootbox.confirm("Yakin <b style='color:red'>MEMBATALKAN</b> Pembelian ini?", function(respond){
			if (respond) {
				var id = ini.find('.id').html();
				window.location.replace(baseurl+'transaction/pembelian_list_batal?id='+id);


			};
		});
	}) ;  

	$('#general_table').on('click','.btn-activate', function(){
		var ini = $(this).closest('tr');
		bootbox.confirm("Yakin <b style='color:blue'>MENGAKTIVASI</b> kembali Pembelian ini?", function(respond){
			if (respond) {
				var id = ini.find('.id').html();
				window.location.replace(baseurl+'transaction/pembelian_list_undo_batal?id='+id);


			};
		});
	}) ;  



	// $('#rekap_barang_list').on('click','.btn-remove-list',function(){
	// 	$(this).closest('tr').remove();
	// });

	// $('#rekap_barang_list').on('change','[name="qty[]"], [name="harga_beli[]"]',function(){
	// 	var qty = $('#rekap_barang_list [name="qty[]"]').val();
	// 	var harga = reset_number_format($('#rekap_barang_list [name="harga_beli[]"]').val());

	// 	// alert(qty);
	// 	var total = qty * harga;
	// 	total = change_number_format(total);
	// 	$('#rekap_barang_list .total').html(total);

	// 	var subtotal = 0;
	// 	$('#rekap_barang_list .total').each(function(){
	// 		subtotal += reset_number_format($(this).html());
	// 	});

	// 	$('#rekap_harga .subtotal').html(change_number_format(subtotal));
	// 	var diskon = reset_number_format($('#rekap_harga .diskon').val());
	// 	var grand_total = parseInt(subtotal) - parseInt(diskon);
	// 	$('#rekap_harga .grand_total').html(change_number_format(grand_total));

	// });

	// $('#rekap_harga [name=diskon]').change(function(){
	// 	var diskon = reset_number_format($(this).val());
	// 	var subtotal = reset_number_format($('#rekap_harga .subtotal').html());
	// 	var grand_total = subtotal - diskon;
	// 	$('#rekap_harga .grand_total').html(change_number_format(grand_total));
	// });


	


});
</script>
