<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css'); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/global/plugins/datatables/extensions/ColReorder/css/dataTables.colReorder.min.css'); ?>"/>
<?php echo link_tag('assets/global/plugins/bootstrap-datepicker/css/datepicker3.css'); ?>

<div class="page-content">
	<div class='container'>

		<div class="modal fade" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('transaction/dp_masuk_insert')?>" class="form-horizontal" id="form_add_data" method="post">
							<h3 class='block'> Penjualan Baru</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<input name='customer_id' value='<?=$customer_id;?>' hidden='hidden'>
			                    	<input class='form-control date-picker' name='tanggal' value="<?=date('d/m/Y');?>">
			                    </div>
			                </div>			                

			                <div class="form-group">
			                    <label class="control-label col-md-3">Jumlah<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='amount' class='form-control amount_number' >
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Metode Pembayaran<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select name='bayar_dp_id' class='form-control' >
	                    				<?foreach ($bayar_dp_list as $row) { ?>
	                    					<option value='<?=$row->id;?>'><?=$row->nama?></option>
	                    				<?}?>
	                    			</select>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Penyerah<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='penyerah' class='form-control' >
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Penerima<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='penerima' class='form-control' >
			                    </div>
			                </div> 
			                <div class="form-group">
			                    <label class="control-label col-md-3">Keterangan
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='keterangan' class='form-control'>
			                    </div>
			                </div> 

						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-save">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="modal fade" id="portlet-config-edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<form action="<?=base_url('transaction/dp_masuk_update')?>" class="form-horizontal" id="form_edit_data" method="post">
							<h3 class='block'> Penjualan Baru</h3>
							
							<div class="form-group">
			                    <label class="control-label col-md-3">Tanggal<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
			                    	<input name='dp_masuk_id' hidden='hidden'>
			                    	<input name='customer_id' value='<?=$customer_id;?>' hidden='hidden'>
			                    	<input class='form-control date-picker' name='tanggal' value="<?=date('d/m/Y');?>">
			                    </div>
			                </div>			                

			                <div class="form-group">
			                    <label class="control-label col-md-3">Jumlah<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='amount' class='form-control amount_number' >
			                    </div>
			                </div>

			                <div class="form-group">
			                    <label class="control-label col-md-3">Metode Pembayaran<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<select name='bayar_dp_id' class='form-control' >
	                    				<?foreach ($bayar_dp_list as $row) { ?>
	                    					<option value='<?=$row->id;?>'><?=$row->nama;?></option>
	                    				<?}?>
	                    			</select>
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Penyerah<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='penyerah' class='form-control' >
			                    </div>
			                </div> 

			                <div class="form-group">
			                    <label class="control-label col-md-3">Penerima<span class="required">
			                    * </span>
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='penerima' class='form-control' >
			                    </div>
			                </div> 
			                <div class="form-group">
			                    <label class="control-label col-md-3">Keterangan
			                    </label>
			                    <div class="col-md-6">
	                    			<input name='keterangan' class='form-control'>
			                    </div>
			                </div> 

						</form>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn blue btn-edit-save">Save</button>
						<button type="button" class="btn default" data-dismiss="modal">Close</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

		<div class="row margin-top-10">
			<div class="col-md-12">
				<div class="portlet light">
					<div class="portlet-title">
						<div class="caption caption-md">
							<i class="icon-bar-chart theme-font hide"></i>
							<span class="caption-subject theme-font bold uppercase"><?=$breadcrumb_small;?></span>
						</div>
						<div class="actions">
							<a href="#portlet-config" data-toggle='modal' class="btn btn-default btn-sm btn-form-add">
							<i class="fa fa-plus"></i> Tambah </a>
						</div>
					</div>
					<div class="portlet-body">
						<form>
							<table>
								<tr>
									<td>Tanggal</td>
									<td>
										<div class="input-group input-large date-picker input-daterange">
											<input type="text" style='border:none; border-bottom:1px solid #ddd; background:white' class="form-control" name="from" value='<?=is_reverse_date($from); ?>'>
											<span class="input-group-addon">
											s/d </span>
											<input type="text" style='border:none; border-bottom:1px solid #ddd; background:white' class="form-control" name="to" value='<?=is_reverse_date($to); ?>'>
										</div>
									</td>
									<td>
										<button class='btn btn-sm green'><i class='fa fa-search'></i></button>
									</td>
								</tr>
							</table>
						</form>
						<hr/>
						<table class="table table-striped table-bordered table-hover" id="general_table">
							<thead>
								<tr>
									<th scope="col">
										Tanggal
									</th>
									<th scope="col">
										DP Masuk
									</th>
									<th scope="col">
										DP Keluar
									</th>
									<th scope="col">
										Saldo
									</th>
									<th scope="col">
										Faktur
									</th>
									<th scope="col">
										Metode Bayar
									</th>
									<th scope="col">
										Keterangan
									</th>
									<th scope="col" style="min-width:150px !important">
										Actions
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										
									</td>
									<td>
									</td>
									<td>
									</td>
									<td>
										<span style='font-size:1.2em'><b><?=number_format($saldo_awal,'0',',','.');?></b></span> 
									</td>
									<td>
									</td>
									<td>
										<b>Saldo Awal</b>
									</td>
									<td>
									</td>
									<td>
										
									</td>
								</tr>
								<?
								$saldo_akhir = $saldo_awal;
								foreach ($dp_list_detail as $row) { ?>
									<tr>
										<td>
											<span class='id' hidden="hidden"><?=$row->id;?></span>
											<span class='tanggal'><?=is_reverse_date($row->tanggal);?></span>
										</td>
										<td>
											<?if ($row->dp_masuk == null || $row->dp_masuk == 0) {
												echo '-';
											}else{ ?>
												<span class='dp_masuk'><?=number_format($row->dp_masuk,'0',',','.');?></span>
											<?}?>
											<a data-toggle="popover" class='btn btn-xs blue default' data-trigger='hover' title="Data" data-html="true" data-content="penyerah : <?=$row->penyerah;?> <br/> penerima: <?=$row->penerima;?>"><i class='fa fa-info'></i></a>
										</td>
										<td>
											<?if ($row->dp_keluar == null || $row->dp_keluar == 0) {
												echo '-';
											}else{ ?>
												<span class='dp_keluar'><?=number_format($row->dp_keluar,'0',',','.');?></span>
											<?}?>
										</td>
										<td>
											<?$saldo_akhir += $row->dp_masuk - $row->dp_keluar;?>
											<?=number_format($saldo_akhir,'0',',','.');?>
										</td>
										<td>
											<span class='no_faktur_lengkap'><?=$row->no_faktur_lengkap;?></span>
										</td>
										<td>
											<span class='bayar_dp_id' hidden='hidden'><?=$row->bayar_dp_id;?></span>
											<?=$row->bayar_dp;?>
										</td>
										<td>
											<span class='keterangan'><?=$row->keterangan;?></span>
										</td>
										<td>
											<span class='penyerah' hidden='hidden'><?=$row->penyerah?></span>
											<span class='penerima' hidden='hidden'><?=$row->penerima?></span>
											<?if ($row->dp_masuk != null || $row->dp_masuk != 0) { ?>
												<a href="#portlet-config-edit" data-toggle='modal' class="btn-xs btn green btn-edit" ><i class="fa fa-edit"></i> </a>
												<a href="<?=base_url();?>transaction/dp_print?id=<?=$row->id;?>" class="btn-xs btn blue btn-print" target='blank'><i class="fa fa-print"></i> </a>
											<?}?>
										</td>
									</tr>
								<? } ?>

							</tbody>
						</table>
					</div>
					<div>
	                  	<a href="<?=base_url().is_setting_link('transaction/dp_list');?>" class="btn btn-lg default button-previous">Back</a>
	                </div>
				</div>
			</div>
		</div>
	</div>			
</div>

<script src="<?php echo base_url('assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/media/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets_noondev/js/table-advanced.js'); ?>"></script>

<script>
jQuery(document).ready(function() {

	// dataTableTrue();

	// oTable = $('#general_table').DataTable();
	// oTable.state.clear();
	// oTable.destroy();
	$('[data-toggle="popover"]').popover();

	$('.btn-save').click(function(){
		if ($('#form_add_data [name=tanggal]').val() != '' && $('#form_add_data [name=amount]').val() != '' ) {
			$('#form_add_data').submit();
		}else{
			alert('Tanggal dan Jumlah harus diisi');
		}
	});

	$('.btn-edit-save').click(function(){
		if ($('#form_edit_data [name=tanggal]').val() != '' && $('#form_edit_data [name=amount]').val() != '' ) {
			$('#form_edit_data').submit();
		}else{
			alert('Tanggal dan Jumlah harus diisi');
		}
	});

	$('#general_table').on('click','.btn-edit', function(){
		var ini = $(this).closest('tr');

		$('#form_edit_data [name=dp_masuk_id]').val(ini.find('.id').html());
		$('#form_edit_data [name=amount]').val(ini.find('.dp_masuk').html());
		$('#form_edit_data [name=penyerah]').val(ini.find('.penyerah').html());
		$('#form_edit_data [name=penerima]').val(ini.find('.penerima').html());
		$('#form_edit_data [name=bayar_dp_id]').val(ini.find('.bayar_dp_id').html());
		$('#form_edit_data [name=keterangan]').val(ini.find('.keterangan').html());

	});

});
</script>
